<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue';
import SummaryList from '../../Components/Dashboard/SummaryList.vue'
</script>

<template>
 <SideNavLayout>
    <SummaryList/>
 </SideNavLayout>
</template>

<style scoped>

</style>
