<script setup>
import CustomerSaveForm from '../../Components/Customer/CustomerSaveForm.vue'
import SideNavLayout from '../../Layout/SideNavLayout.vue'
</script>

<template>
<SideNavLayout>
    <CustomerSaveForm/>
</SideNavLayout>
</template>

<style scoped>

</style>
