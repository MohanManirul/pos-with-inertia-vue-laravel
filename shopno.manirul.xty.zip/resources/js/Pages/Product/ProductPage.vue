<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue'
import ProductList from '../../Components/Product/ProductList.vue'
</script>

<template>
<SideNavLayout>
    <ProductList/>
</SideNavLayout>
</template>

<style scoped>

</style>
