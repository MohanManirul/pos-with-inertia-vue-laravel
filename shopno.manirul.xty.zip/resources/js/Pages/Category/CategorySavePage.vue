<script setup>
import CategorySaveForm from '../../Components/Category/CategorySaveForm.vue'
import SideNavLayout from '../../Layout/SideNavLayout.vue'
</script>

<template>
<SideNavLayout>
    <CategorySaveForm/>
</SideNavLayout>

</template>

<style scoped>

</style>
