<script setup>
 import SideNavLayout from '../../Layout/SideNavLayout.vue'
 import CategoryList from '../../Components/Category/CategoryList.vue'
</script>

<template>
<SideNavLayout>
    <CategoryList/>
</SideNavLayout>
</template>

<style scoped>

</style>
