<script setup>
import ResetPasswordForm from '../../Components/User/ResetPasswordForm.vue'
</script>

<template>
<ResetPasswordForm/>
</template>

<style scoped>

</style>
