<script setup>
import RegistrationForm from '../../Components/User/RegistrationForm.vue'
</script>

<template>
<registration-form/>
</template>

<style scoped>

</style>
