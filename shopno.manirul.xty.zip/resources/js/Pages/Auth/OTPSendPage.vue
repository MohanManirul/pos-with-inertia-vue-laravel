<script setup>
import SendOTPForm from '../../Components/User/SendOTPForm.vue'
</script>

<template>
<SendOTPForm/>
</template>

<style scoped>

</style>
