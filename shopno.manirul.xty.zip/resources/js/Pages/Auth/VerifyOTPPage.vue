<script setup>
import VerifyOTPForm from '../../Components/User/VerifyOTPForm.vue'
</script>

<template>
<VerifyOTPForm/>
</template>

<style scoped>

</style>
