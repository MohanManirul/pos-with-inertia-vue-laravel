<script setup>
import LoginForm from '../../Components/User/LoginForm.vue'
</script>

<template>
<login-form/>
</template>

<style scoped>

</style>
